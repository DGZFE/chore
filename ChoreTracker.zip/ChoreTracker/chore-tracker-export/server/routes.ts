import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth } from "./auth";
import { storage } from "./storage";
import { insertChoreSchema } from "@shared/schema";
import { ZodError } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  setupAuth(app);

  app.get("/api/chores", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const chores = await storage.getChoresByUserId(req.user.id);
    res.json(chores);
  });

  app.post("/api/chores", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    try {
      const data = insertChoreSchema.parse(req.body);
      const chore = await storage.createChore({
        ...data,
        userId: req.user.id,
      });
      res.status(201).json(chore);
    } catch (err) {
      if (err instanceof ZodError) {
        res.status(400).json(err.message);
      } else {
        throw err;
      }
    }
  });

  app.delete("/api/chores/:id", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const chore = await storage.getChore(parseInt(req.params.id));
    if (!chore || chore.userId !== req.user.id) {
      return res.sendStatus(404);
    }
    await storage.deleteChore(chore.id);
    res.sendStatus(200);
  });

  app.patch("/api/chores/:id/toggle", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);
    const chore = await storage.getChore(parseInt(req.params.id));
    if (!chore || chore.userId !== req.user.id) {
      return res.sendStatus(404);
    }
    const updated = await storage.toggleChore(chore.id);
    res.json(updated);
  });

  const httpServer = createServer(app);
  return httpServer;
}
