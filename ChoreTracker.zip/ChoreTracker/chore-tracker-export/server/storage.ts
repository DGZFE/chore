import { users, type User, type InsertUser, type Chore, type InsertChore } from "@shared/schema";
import session from "express-session";
import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  getChore(id: number): Promise<Chore | undefined>;
  getChoresByUserId(userId: number): Promise<Chore[]>;
  createChore(chore: InsertChore & { userId: number }): Promise<Chore>;
  deleteChore(id: number): Promise<void>;
  toggleChore(id: number): Promise<Chore>;
  sessionStore: session.Store;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private chores: Map<number, Chore>;
  sessionStore: session.Store;
  currentId: number;
  currentChoreId: number;

  constructor() {
    this.users = new Map();
    this.chores = new Map();
    this.currentId = 1;
    this.currentChoreId = 1;
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // 24 hours
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getChore(id: number): Promise<Chore | undefined> {
    return this.chores.get(id);
  }

  async getChoresByUserId(userId: number): Promise<Chore[]> {
    return Array.from(this.chores.values()).filter(
      (chore) => chore.userId === userId,
    );
  }

  async createChore(data: InsertChore & { userId: number }): Promise<Chore> {
    const id = this.currentChoreId++;
    const chore: Chore = {
      id,
      userId: data.userId,
      name: data.name,
      reward: data.reward,
      completed: false,
    };
    this.chores.set(id, chore);
    return chore;
  }

  async deleteChore(id: number): Promise<void> {
    this.chores.delete(id);
  }

  async toggleChore(id: number): Promise<Chore> {
    const chore = this.chores.get(id);
    if (!chore) {
      throw new Error("Chore not found");
    }
    const updated: Chore = { ...chore, completed: !chore.completed };
    this.chores.set(id, updated);
    return updated;
  }
}

export const storage = new MemStorage();