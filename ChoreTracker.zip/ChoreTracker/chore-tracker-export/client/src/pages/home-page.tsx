import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertChoreSchema, InsertChore, Chore } from "@shared/schema";
import { useMutation, useQuery } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useRef } from "react";
import { Check, Loader2, LogOut, Printer, Trash2 } from "lucide-react";
import { useReactToPrint } from "react-to-print";

export default function HomePage() {
  const { user, logoutMutation } = useAuth();
  const { toast } = useToast();
  const printRef = useRef<HTMLDivElement>(null);
  const handlePrint = useReactToPrint({
    content: () => printRef.current,
  });

  const { data: chores, isLoading } = useQuery<Chore[]>({
    queryKey: ["/api/chores"],
  });

  const createChoreMutation = useMutation({
    mutationFn: async (chore: InsertChore) => {
      const res = await apiRequest("POST", "/api/chores", chore);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chores"] });
      toast({ title: "Chore created successfully" });
    },
  });

  const deleteChoreMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("DELETE", `/api/chores/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chores"] });
      toast({ title: "Chore deleted successfully" });
    },
  });

  const toggleChoreMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest("PATCH", `/api/chores/${id}/toggle`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/chores"] });
    },
  });

  const form = useForm<InsertChore>({
    resolver: zodResolver(insertChoreSchema),
    defaultValues: {
      name: "",
      reward: 0,
    },
  });

  function onSubmit(data: InsertChore) {
    createChoreMutation.mutate(data);
    form.reset();
  }

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="h-8 w-8 animate-spin text-border" />
      </div>
    );
  }

  const totalRewards = chores?.reduce((sum, chore) => 
    chore.completed ? sum + chore.reward : sum, 0
  ) ?? 0;

  return (
    <div className="min-h-screen p-8 max-w-4xl mx-auto">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Welcome, {user?.username}!</h1>
          <p className="text-muted-foreground">
            Total Rewards Earned: ${totalRewards.toFixed(2)}
          </p>
        </div>
        <div className="space-x-4">
          <Button variant="outline" onClick={handlePrint}>
            <Printer className="w-4 h-4 mr-2" />
            Print
          </Button>
          <Button variant="destructive" onClick={() => logoutMutation.mutate()}>
            <LogOut className="w-4 h-4 mr-2" />
            Logout
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-8">
        <Card>
          <CardHeader>
            <CardTitle>Add New Chore</CardTitle>
          </CardHeader>
          <CardContent>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
                <FormField
                  control={form.control}
                  name="name"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Chore Name</FormLabel>
                      <FormControl>
                        <Input {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="reward"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Reward Amount ($)</FormLabel>
                      <FormControl>
                        <Input type="number" step="0.01" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={createChoreMutation.isPending}>
                  Add Chore
                </Button>
              </form>
            </Form>
          </CardContent>
        </Card>

        <div ref={printRef}>
          <Card>
            <CardHeader>
              <CardTitle>Chore List</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {chores?.map((chore) => (
                  <div
                    key={chore.id}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div className="flex items-center gap-4">
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => toggleChoreMutation.mutate(chore.id)}
                      >
                        <Check className={`w-4 h-4 ${chore.completed ? "text-green-500" : "text-gray-300"}`} />
                      </Button>
                      <span className={chore.completed ? "line-through text-muted-foreground" : ""}>
                        {chore.name}
                      </span>
                      <span className="text-muted-foreground">
                        ${chore.reward.toFixed(2)}
                      </span>
                    </div>
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => deleteChoreMutation.mutate(chore.id)}
                    >
                      <Trash2 className="w-4 h-4 text-destructive" />
                    </Button>
                  </div>
                ))}
                {(!chores || chores.length === 0) && (
                  <p className="text-center text-muted-foreground">
                    No chores added yet
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
