import { pgTable, text, serial, integer, boolean } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  householdId: integer("household_id"),
  isHouseholdAdmin: boolean("is_household_admin").default(false),
});

export const households = pgTable("households", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
});

export const chores = pgTable("chores", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  householdId: integer("household_id").notNull(),
  name: text("name").notNull(),
  reward: integer("reward").notNull(),
  completed: boolean("completed").notNull().default(false),
  assignedTo: integer("assigned_to"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertHouseholdSchema = createInsertSchema(households);

export const insertChoreSchema = createInsertSchema(chores)
  .pick({
    name: true,
    reward: true,
    assignedTo: true,
  })
  .extend({
    reward: z.coerce.number().min(0),
    assignedTo: z.number().optional(),
  });

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertHousehold = z.infer<typeof insertHouseholdSchema>;
export type Household = typeof households.$inferSelect;
export type InsertChore = z.infer<typeof insertChoreSchema>;
export type Chore = typeof chores.$inferSelect;